This is a random Database Management Project I made for fun
Made using Node-js and MongoDB
Enjoy!
Suggest any nice changes xD
